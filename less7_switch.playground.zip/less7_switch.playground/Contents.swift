//Оператор Switch

//1) оператор if
var animal = "cat"

print("1)Пример оператора IF:")
if animal == "cat" {
    print("it's a cat!")
}else if animal == "dog" {
    print("it's a dog!")
}else if animal == "bird" {
    print("it's a bird!")
}else {
    print("I don't know kind of animal...")
}

//2) тоже самое, но в Switch
print("2)Тоже самое, но в switch:")

switch animal {
case "cat":
    print("It's a cat!")
case "dog":
    print("it's a dog!")
case "bird", "dove", "sparrow":
    print("it's a bird!")
default:
    print("I don't know kind of animal...")
}

//еще один пример в switch
print("Еще один пример switch:")
print("How many people?")
let numberOfPeople = 5
var amount = ""

switch numberOfPeople {
case ..<0:
    print("it's impossible!")
case 0:
    amount = "no"
case 1:
    amount = "one"
case 2...5:
    amount = "few"
case 6..<10:
    amount = "enough"
case 10...30:
    amount = "many"
default:
    amount = "too many"
}
print("\(amount)\n")
//HW -7 Switch
/*
 Какую одежду надеть выходя на улицу, в зависимости от погоды
 */
print("самомстоятельная работа:\"Свой пример на switch:\"\n")
print("Рекомендации по выбору одежды в зависимости от погоды:")
let temperature = (-40)
var tempDescription = ""
var clothes = ""

switch temperature {
case ..<(-10):
    tempDescription = "Внимание!!! На улице сильный мороз! Лучше надеть пуховик, зимние брюки, и зимние ботинки!"
    //print("Внимание!!! На улице \(tempDescription), нужно надеть Пуховик, зимние брюки, и зимние ботинки!")
case (-9)...(-5):
    tempDescription = "На улице легкий морозец, нужно надеть синтепоновую куртку, брюки и ботинки!"
    //print("На улице \(tempDescription), нужно надеть синтепоновую куртку, брюки и ботинки!")
case -4...10:
    tempDescription = "На улице прохладно, можно надеть пальто, кашне, брюки и туфли. "
    //print("На улице \(tempDescription), можно надеть пальто, кашне, брюки и туфли. ")
case 11...18:
    tempDescription = "На улице легкая прохлада, можно надеть свитшот, джинсы, кроссовки."
    //print("На улице \(tempDescription), можно надеть свитшот, джинсы, кроссовки.")
case 19...21:
    tempDescription = "На улице тепло, можно надеть рубашку, пиджак, брюки, кеды."
    //print("На улице \(tempDescription), можно надеть рубашку, пиджак, брюки, кеды.")
case 22...25:
    tempDescription = "На улице очень тепло, уже можно ходить в футболке, шортах, кедах! Здравствуй лето!"
    //print("На улице \(tempDescription), уже можно ходить в футболке, шортах, кедах!")
default:
    tempDescription = "Внимание! на улице очень жарко! возьмите воду, наденьте кепку на голову, футболку, шорты и шлепки! Лучше побыть дома!"
    //print("Внимание! на улице \(tempDescription), возьмите воду, наденьте кепку на голову, футболку, шорты и шлепки! Лучше побыть дома!")
}
print(tempDescription)

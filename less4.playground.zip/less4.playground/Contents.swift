//ОПЦИОНАЛЬНЫЕ ТИПЫ
//нужны для обозначения отстутствия
/*
 Пример,
 1-день: продажи 70р + 20р = 90р
 2-день: продажи 10р возврат 10р = 0р
 3-день: продаж нет. Это "nil" отсутствие, а не 0
 */
/* var apples :Int? = 5 //опциональный Int
//apples = nil //так можно сделать только если Int опциональный
    //каждый опциональный результат нужно проверять
if apples == nil {
    print("Nil apples")
}else {
    print(apples)
    apples = apples! + 2 //если яблоки есть, то положить еще 2
    /*"!" ствится при принудительном разворачивании (Force Unwrapping) типа из опционального, тк складывать опционал и неопционал нельзя
     */
} */

let boyAge = "60"

/*if let ageNumber = age.toInt() {
    print(ageNumber)
}*/

if Int(boyAge) != nil {
    let ageNumber = Int(boyAge)!
} else {
    print("else")
}

var numNil : Int? = 5
numNil = nil

//всегда нужно проверять на nil!!
if numNil == nil {
    print("numNil is NIL")
}else {
    //print(numNil ?? 0)
    print(numNil!) //Force Unwrapping
}

//есть еще вариант без unwraping
var apples2 : Int! = nil
apples2 = 2
apples2 += 2

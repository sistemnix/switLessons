//ТЮПЛЫ (Tuples) - кортежи ()

//Тюплы это набор разных типов в одну константу
let simpleTuples = (1, "Hello", true, 2.4)
//можно насильно указать типы
//let simpleTuples : (Int, String, Bool, Double) = (1, "Hello", true, 2.4)


//Мой пример
let student1 = ("Ivanov", "Ivan", "Ivanovich", 2008, "1course")
let (surname, name, patronymic, yaersOfBirth, course) = student1
surname
//каждый параметр имеет свой индекс начиная с 0
//можно ообращаться по индексу
student1.0 //ображение к тюплу student1 к нулевому индексу
print(student1.0)
print(surname)
let Ivan = (pushUps:15, pullUps:10, squats:25)

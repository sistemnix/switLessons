let redColor = "red"
var color = "green"
let blueColor = "blue"

print(blueColor)
print("The color cars = \(blueColor)")

//Home Work

//students names
let student1 = "Ivan"
let student2 = "Eva"
let student3 = "Alex"
//students years old
var ivanAge = 22
var evaAge = 22
var alexAge = 23
//students height
var ivanHeight = 170
var evaHeight = 178
var alexHeight = 190
//students weight
var ivanWeight = 85
var evaWeight = 48
var alexWeight = 80
var ivanCourse = 1
var evaCourse = 2
var alexCourse = 3

print("Student1 \(student1): \(ivanAge) Years Old, \(ivanHeight) sm height, \(ivanWeight) kg weight, \(ivanCourse) cours")
print("Student2 \(student2): \(evaAge) Years Old, \(evaHeight) sm height, \(evaWeight) kg weight, \(evaCourse) cours")
print("Student3 \(student3): \(alexAge) Years Old, \(alexHeight) sm height, \(alexWeight) kg weight, \(alexCourse) cours")


